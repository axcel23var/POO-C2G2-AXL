package pe.edu.upeu.conceptos_poo.pleystation.repository;

import pe.edu.upeu.conceptos_poo.pleystation.modelos.UnidadMedida;

public interface IUnidadMedidaRepository extends ICrudGenericoRepository<UnidadMedida,Long>{

}
