package pe.edu.upeu.conceptos_poo.pleystation.service;

import pe.edu.upeu.conceptos_poo.pleystation.dto.ModeloDataAutocomplet;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Cliente;

import java.util.List;

public interface ClienteService extends CRUD_GenericoSefvice_Interface<Cliente, String> {
    List<ModeloDataAutocomplet> listAutoCompletCliente();
}
