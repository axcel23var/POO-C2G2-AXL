package pe.edu.upeu.conceptos_poo.pleystation.repository;
import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Venta;

@Repository
public interface IVentaRepository extends ICrudGenericoRepository<Venta, Long> {
}