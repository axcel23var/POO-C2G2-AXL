package pe.edu.upeu.conceptos_poo.pleystation.service;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Venta;
import net.sf.jasperreports.engine.JasperPrint; // [NUEVA LÍNEA]

public interface VentaService extends CRUD_GenericoSefvice_Interface<Venta, Long> {// Puedes añadir métodos específicos si los necesitas después

    // [NUEVO MÉTODO]
    JasperPrint generarBoleta(Long idVenta);
}