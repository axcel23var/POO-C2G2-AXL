package pe.edu.upeu.conceptos_poo.pleystation.service;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.DetalleVenta;

public interface DetalleVentaService extends CRUD_GenericoSefvice_Interface<DetalleVenta, Long> {
}
