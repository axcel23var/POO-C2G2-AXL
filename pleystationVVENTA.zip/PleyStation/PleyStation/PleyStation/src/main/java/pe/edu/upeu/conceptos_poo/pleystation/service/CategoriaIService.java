package pe.edu.upeu.conceptos_poo.pleystation.service;

import javafx.scene.control.ComboBox;
import pe.edu.upeu.conceptos_poo.pleystation.dto.ComboBoxOption;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Categoria;
import pe.edu.upeu.conceptos_poo.pleystation.repository.ICrudGenericoRepository;

import java.util.List;

public interface CategoriaIService extends CRUD_GenericoSefvice_Interface<Categoria, Long> {
    List<ComboBoxOption> listarCombobox();
}
