package pe.edu.upeu.conceptos_poo.pleystation.enums;

public enum TipoDocumento {
    DNI,
    RUC
}
