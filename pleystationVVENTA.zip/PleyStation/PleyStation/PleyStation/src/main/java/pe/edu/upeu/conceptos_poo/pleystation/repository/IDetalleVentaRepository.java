package pe.edu.upeu.conceptos_poo.pleystation.repository;
import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.DetalleVenta;

@Repository
public interface IDetalleVentaRepository extends ICrudGenericoRepository<DetalleVenta, Long> {
}