package pe.edu.upeu.conceptos_poo.pleystation.repository;

import pe.edu.upeu.conceptos_poo.pleystation.modelos.Perfil;

public interface IPerfilRepository extends ICrudGenericoRepository<Perfil,Long>{
}
