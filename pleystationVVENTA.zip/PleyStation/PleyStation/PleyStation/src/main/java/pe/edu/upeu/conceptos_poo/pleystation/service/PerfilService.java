package pe.edu.upeu.conceptos_poo.pleystation.service;

import pe.edu.upeu.conceptos_poo.pleystation.modelos.Perfil;

public interface PerfilService extends CRUD_GenericoSefvice_Interface<Perfil, Long>{
}
