package pe.edu.upeu.conceptos_poo.pleystation;

public class Application {
    public static void main(String[] args) {
        PleyStationAplication.main(args);
    }
}
