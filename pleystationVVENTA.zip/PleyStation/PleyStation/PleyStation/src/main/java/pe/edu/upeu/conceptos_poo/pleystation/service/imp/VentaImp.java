package pe.edu.upeu.conceptos_poo.pleystation.service.imp;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Venta;
import pe.edu.upeu.conceptos_poo.pleystation.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.pleystation.repository.IVentaRepository;
import pe.edu.upeu.conceptos_poo.pleystation.service.VentaService;

// [NUEVAS IMPORTACIONES]
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
// [FIN NUEVAS IMPORTACIONES]

@Service
@RequiredArgsConstructor
public class VentaImp extends CRUD_GenericoServiceImp<Venta, Long> implements VentaService {

    private final IVentaRepository ventaRepository;

    @Override
    protected ICrudGenericoRepository<Venta, Long> getRepository() {
        return ventaRepository;
    }

    @Override
    @Transactional
    public Venta save(Venta venta) {
        return super.save(venta);
    }

    // [IMPLEMENTACIÓN DEL NUEVO MÉTODO]
    @Override
    public JasperPrint generarBoleta(Long idVenta) {
        try {
            Optional<Venta> ventaOpt = ventaRepository.findById(idVenta);
            if (ventaOpt.isEmpty()) return null;

            Venta venta = ventaOpt.get();

            // 1. Carga el archivo del reporte compilado (.jasper)
            // Asegúrate de que este archivo esté en src/main/resources/reports/
            InputStream reportStream = getClass().getResourceAsStream("/reports/boleta_venta.jasper");

            if (reportStream == null) {
                System.err.println("CRÍTICO: El archivo de reporte '/reports/boleta_venta.jasper' no fue encontrado.");
                return null;
            }

            // 2. Preparar los parámetros (datos del cliente/venta)
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ID_VENTA", venta.getIdVenta());
            parameters.put("CLIENTE_DNI", venta.getDniCliente());
            parameters.put("CLIENTE_NOMBRE", venta.getNombreCliente() + " " + venta.getApellidoCliente());
            parameters.put("FECHA_VENTA", venta.getFechaVenta().toLocalDate().toString());
            parameters.put("TOTAL", venta.getMontoTotal());
            parameters.put("METODO_PAGO", venta.getMetodoPago());
            parameters.put("USUARIO", venta.getUsuario().getNombre_Usuario()); // Asume que el usuario está cargado

            // 3. Fuente de datos para el detalle (tabla de productos)
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(venta.getDetalleVenta());

            // 4. Llenar el reporte
            return JasperFillManager.fillReport(reportStream, parameters, dataSource);

        } catch (Exception e) {
            System.err.println("Error al generar la boleta de venta: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}