package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.enums.TipoDocumento;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Cliente;
import pe.edu.upeu.conceptos_poo.pleystation.service.ClienteService;

@Controller
public class BuscarClienteDialogController {

    @FXML private TextField txtDniRuc, txtNombres, txtEmail;
    @FXML private ComboBox<TipoDocumento> cbTipoDocumento;
    @FXML private Button btnConfirmarCliente;
    @FXML private Label lblMensajeCliente;

    @Autowired private ClienteService clienteService;
    private Stage dialogStage;
    private Cliente clienteEncontrado;

    @FXML
    public void initialize() {
        cbTipoDocumento.setItems(FXCollections.observableArrayList(TipoDocumento.values()));
        txtNombres.setDisable(true);
        txtEmail.setDisable(true);
        cbTipoDocumento.setDisable(true);
    }

    public void setDialogStage(Stage dialogStage) { this.dialogStage = dialogStage; }
    public Cliente getClienteSeleccionado() { return this.clienteEncontrado; }

    @FXML
    private void buscarCliente() {
        String dni = txtDniRuc.getText().trim();
        if (dni.isEmpty()) return;

        this.clienteEncontrado = clienteService.findByIdOrNull(dni);

        txtNombres.setDisable(false);
        txtEmail.setDisable(false);
        cbTipoDocumento.setDisable(false);

        if (clienteEncontrado != null) {
            txtNombres.setText(clienteEncontrado.getNombres());
            txtEmail.setText(clienteEncontrado.getEmail());
            cbTipoDocumento.setValue(clienteEncontrado.getTipoDocumento());
            lblMensajeCliente.setText("Cliente encontrado.");
        } else {
            lblMensajeCliente.setText("Cliente no encontrado. Regístrelo.");
            txtNombres.clear();
            txtEmail.clear();
            cbTipoDocumento.setValue(null);
        }
    }

    @FXML
    private void confirmarSeleccion() {
        String dni = txtDniRuc.getText().trim();
        String nom = txtNombres.getText().trim();
        String email = txtEmail.getText().trim();
        TipoDocumento tipo = cbTipoDocumento.getValue();

        if (dni.isEmpty() || nom.isEmpty() || tipo == null) {
            lblMensajeCliente.setText("Complete los campos obligatorios.");
            return;
        }

        if (clienteEncontrado == null) {
            clienteEncontrado = new Cliente();
            clienteEncontrado.setDniruc(dni);
        }
        clienteEncontrado.setNombres(nom);
        clienteEncontrado.setEmail(email);
        clienteEncontrado.setTipoDocumento(tipo);

        clienteService.save(clienteEncontrado);
        dialogStage.close();
    }
}