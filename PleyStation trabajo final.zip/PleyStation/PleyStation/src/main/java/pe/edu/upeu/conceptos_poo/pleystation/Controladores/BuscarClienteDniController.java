package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.enums.TipoDocumento;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Cliente;
import pe.edu.upeu.conceptos_poo.pleystation.service.ClienteService;
import pe.edu.upeu.conceptos_poo.pleystation.utils.ConsultaDNI;

import java.util.Map;

@Controller
public class BuscarClienteDniController {

    @FXML private TextField txtDni;
    @FXML private Button btnBuscarDni;
    @FXML private TextField txtNombres;
    @FXML private TextField txtDireccion;
    @FXML private ComboBox<TipoDocumento> cbTipoDocumento;
    @FXML private Label lblMensaje;
    @FXML private Button btnConfirmarCliente;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ConsultaDNI consultaDNI; // Inyectamos el util de scraping

    private Stage dialogStage;
    private Cliente clienteSeleccionado = null; // Guardará el cliente final

    @FXML
    public void initialize() {
        cbTipoDocumento.setItems(FXCollections.observableArrayList(TipoDocumento.values()));
        cbTipoDocumento.setValue(TipoDocumento.DNI); // Por defecto es DNI

        // El botón de confirmar está deshabilitado hasta que se busquen datos
        btnConfirmarCliente.setDisable(true);
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    /**
     * Devuelve el cliente (ya sea encontrado, actualizado o creado)
     * @return Cliente
     */
    public Cliente getClienteSeleccionado() {
        return this.clienteSeleccionado;
    }

    @FXML
    private void buscarDniEnWeb() {
        String dni = txtDni.getText().trim();
        if (dni.length() != 8 || !dni.matches("\\d+")) {
            lblMensaje.setText("Error: El DNI debe contener 8 dígitos numéricos.");
            lblMensaje.setStyle("-fx-text-fill: red;");
            return;
        }

        lblMensaje.setText("Buscando DNI en la web, por favor espere...");
        lblMensaje.setStyle("-fx-text-fill: blue;");
        btnBuscarDni.setDisable(true);
        btnConfirmarCliente.setDisable(true);

        // Realizar la búsqueda en un hilo separado para no bloquear la UI
        new Thread(() -> {
            Map<String, String> datos = consultaDNI.buscarDatosPorDni(dni);

            Platform.runLater(() -> {
                if (datos.isEmpty()) {
                    // No encontrado en la web, permitir ingreso manual
                    lblMensaje.setText("DNI no encontrado. Ingrese los datos manualmente.");
                    lblMensaje.setStyle("-fx-text-fill: orange;");
                    txtNombres.setDisable(false);
                    txtDireccion.setDisable(false);
                    cbTipoDocumento.setDisable(false); // Permitir cambiar si es RUC (aunque buscamos DNI)
                    txtNombres.clear();
                    txtDireccion.clear();
                } else {
                    // Encontrado en la web
                    lblMensaje.setText("Datos encontrados. Verifique y corrija si es necesario.");
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    txtNombres.setText(datos.getOrDefault("nombres", ""));
                    txtDireccion.setText(datos.getOrDefault("direccion", ""));
                    cbTipoDocumento.setValue(TipoDocumento.DNI);

                    // Habilitar campos para edición
                    txtNombres.setDisable(false);
                    txtDireccion.setDisable(false);
                    cbTipoDocumento.setDisable(false);
                }
                btnBuscarDni.setDisable(false);
                btnConfirmarCliente.setDisable(false); // Habilitar confirmación
            });
        }).start();
    }

    @FXML
    private void confirmarSeleccion() {
        String dniRuc = txtDni.getText().trim();
        String nombres = txtNombres.getText().trim();
        String direccion = txtDireccion.getText().trim();
        TipoDocumento tipo = cbTipoDocumento.getValue();

        if (dniRuc.isEmpty() || nombres.isEmpty() || tipo == null) {
            lblMensaje.setText("DNI/RUC, Nombres y Tipo Documento son obligatorios.");
            lblMensaje.setStyle("-fx-text-fill: red;");
            return;
        }

        try {
            // Buscamos en NUESTRA base de datos
            Cliente cliente = clienteService.findById(dniRuc);

            if (cliente != null) {
                // Cliente EXISTE en nuestra DB, lo actualizamos
                cliente.setNombres(nombres);
                cliente.setDireccion(direccion);
                cliente.setTipoDocumento(tipo);
                this.clienteSeleccionado = clienteService.save(cliente);
                lblMensaje.setText("Cliente actualizado en la base de datos.");
            } else {
                // Cliente NUEVO, lo creamos
                Cliente nuevoCliente = Cliente.builder()
                        .dniruc(dniRuc)
                        .nombres(nombres)
                        .direccion(direccion)
                        .tipoDocumento(tipo)
                        .build();
                this.clienteSeleccionado = clienteService.save(nuevoCliente);
                lblMensaje.setText("Nuevo cliente registrado en la base de datos.");
            }

            lblMensaje.setStyle("-fx-text-fill: green;");
            dialogStage.close(); // Cerrar el diálogo

        } catch (Exception e) {
            lblMensaje.setText("Error al guardar cliente: " + e.getMessage());
            lblMensaje.setStyle("-fx-text-fill: red;");
            e.printStackTrace();
        }
    }
}