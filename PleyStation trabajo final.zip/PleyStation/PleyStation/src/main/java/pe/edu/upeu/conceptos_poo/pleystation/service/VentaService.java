package pe.edu.upeu.conceptos_poo.pleystation.service;

import pe.edu.upeu.conceptos_poo.pleystation.modelos.Venta;

import java.time.LocalDateTime; // Importar
import java.util.List; // Importar

public interface VentaService extends CRUD_GenericoSefvice_Interface<Venta, Long> {

    Venta registrarVentaCompleta(Venta venta) throws RuntimeException;

    //METODO PARA AÑADIR REPORTES
    List<Venta> findVentasBetweenFechas(LocalDateTime inicio, LocalDateTime fin);
}