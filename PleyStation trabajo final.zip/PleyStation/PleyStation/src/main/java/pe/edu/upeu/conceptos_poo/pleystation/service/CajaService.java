package pe.edu.upeu.conceptos_poo.pleystation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.pleystation.dto.SessionManager;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Caja;
import pe.edu.upeu.conceptos_poo.pleystation.repository.ICajaRepository;
import pe.edu.upeu.conceptos_poo.pleystation.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.pleystation.service.imp.CRUD_GenericoServiceImp;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class CajaService extends CRUD_GenericoServiceImp<Caja, Long> {

    @Autowired private ICajaRepository cajaRepository;

    @Override
    protected ICrudGenericoRepository<Caja, Long> getRepository() { return cajaRepository; }

    public Caja abrirCaja(double montoInicial) {
        String usuario = SessionManager.getInstance().getUserName();
        if(cajaRepository.buscarCajaAbierta(usuario).isPresent()) {
            throw new RuntimeException("Ya tienes una caja abierta.");
        }
        Caja caja = new Caja();
        caja.setFechaApertura(LocalDateTime.now());
        caja.setMontoInicial(montoInicial);
        caja.setUsuario(usuario);
        caja.setEstado("ABIERTA");
        return cajaRepository.save(caja);
    }

    public Caja cerrarCaja(double montoReal) {
        String usuario = SessionManager.getInstance().getUserName();
        Caja caja = cajaRepository.buscarCajaAbierta(usuario)
                .orElseThrow(() -> new RuntimeException("No hay caja abierta para cerrar."));

        caja.setFechaCierre(LocalDateTime.now());
        caja.setMontoReal(montoReal);
        caja.setEstado("CERRADA");
        // Aquí podrías calcular el montoFinal sumando ventas del día, pero por brevedad lo dejamos pendiente
        return cajaRepository.save(caja);
    }

    public boolean hayCajaAbierta() {
        return cajaRepository.buscarCajaAbierta(SessionManager.getInstance().getUserName()).isPresent();
    }
}