package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.components.ColumnInfo;
import pe.edu.upeu.conceptos_poo.pleystation.components.TableViewHelper;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.UnidadMedida;
import pe.edu.upeu.conceptos_poo.pleystation.service.UnidadMedidaService;

import java.util.LinkedHashMap;

@Controller
public class GestionUnidadesMedidaController {

    @FXML private TextField txtNombreUnidad;
    @FXML private Button btnGuardar;
    @FXML private Label lblMensaje;
    @FXML private TableView<UnidadMedida> tablaUnidades;

    @Autowired private UnidadMedidaService unidadService;

    private Long idEditando = null;

    @FXML
    public void initialize() {
        configurarTabla();
        listarUnidades();
    }

    private void configurarTabla() {
        TableViewHelper<UnidadMedida> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columnas = new LinkedHashMap<>();
        // Ojo: Los nombres de campos deben coincidir con tu Modelo UnidadMedida
        columnas.put("ID", new ColumnInfo("id_unidad", 50.0));
        columnas.put("Nombre", new ColumnInfo("nombre_medida", 200.0));

        helper.addColumnsInOrderWithSize(tablaUnidades, columnas, this::editarUnidad, this::eliminarUnidad);
    }

    private void listarUnidades() {
        tablaUnidades.setItems(FXCollections.observableArrayList(unidadService.findAll()));
    }

    @FXML
    private void guardarUnidad() {
        String nombre = txtNombreUnidad.getText().trim();
        if (nombre.isEmpty()) {
            mostrarMensaje("El nombre es obligatorio.", true);
            return;
        }

        try {
            UnidadMedida unidad = (idEditando != null) ? unidadService.findById(idEditando) : new UnidadMedida();
            if (unidad == null) unidad = new UnidadMedida();

            unidad.setNombre_medida(nombre);

            if (idEditando != null) unidadService.update(idEditando, unidad);
            else unidadService.save(unidad);

            mostrarMensaje("Unidad guardada exitosamente.", false);
            cancelarEdicion();
            listarUnidades();
        } catch (Exception e) {
            mostrarMensaje("Error: " + e.getMessage(), true);
        }
    }

    private void editarUnidad(UnidadMedida u) {
        idEditando = u.getId_unidad();
        txtNombreUnidad.setText(u.getNombre_medida());
        btnGuardar.setText("Actualizar");
        mostrarMensaje("Editando ID: " + idEditando, false);
    }

    private void eliminarUnidad(UnidadMedida u) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar '" + u.getNombre_medida() + "'?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(r -> {
            if (r == ButtonType.YES) {
                try {
                    unidadService.delete(u.getId_unidad());
                    listarUnidades();
                    mostrarMensaje("Eliminado.", false);
                } catch (Exception e) {
                    mostrarMensaje("No se puede eliminar (en uso).", true);
                }
            }
        });
    }

    @FXML
    private void cancelarEdicion() {
        idEditando = null;
        txtNombreUnidad.clear();
        btnGuardar.setText("Guardar");
        lblMensaje.setText("");
    }

    private void mostrarMensaje(String msg, boolean error) {
        lblMensaje.setText(msg);
        lblMensaje.setStyle(error ? "-fx-text-fill: red;" : "-fx-text-fill: green;");
    }
}