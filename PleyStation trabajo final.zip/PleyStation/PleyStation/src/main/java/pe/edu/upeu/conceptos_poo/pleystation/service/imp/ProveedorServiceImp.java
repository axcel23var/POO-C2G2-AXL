package pe.edu.upeu.conceptos_poo.pleystation.service.imp;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Proveedor;
import pe.edu.upeu.conceptos_poo.pleystation.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.pleystation.repository.IProveedorRepository;
import pe.edu.upeu.conceptos_poo.pleystation.service.ProveedorService;

@Service
@RequiredArgsConstructor
public class ProveedorServiceImp extends CRUD_GenericoServiceImp<Proveedor, Long> implements ProveedorService {

    private final IProveedorRepository proveedorRepository;

    @Override
    protected ICrudGenericoRepository<Proveedor, Long> getRepository() {
        return proveedorRepository;
    }
}