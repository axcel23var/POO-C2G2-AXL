package pe.edu.upeu.conceptos_poo.pleystation.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Caja;
import java.util.Optional;

@Repository
public interface ICajaRepository extends ICrudGenericoRepository<Caja, Long> {
    @Query("SELECT c FROM Caja c WHERE c.estado = 'ABIERTA' AND c.usuario = :usuario")
    Optional<Caja> buscarCajaAbierta(String usuario);
}