package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.dto.SessionManager;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Usuario;
import pe.edu.upeu.conceptos_poo.pleystation.service.UsuarioService;

@Controller
public class CambioClaveController {

    @FXML private PasswordField txtPassActual;
    @FXML private PasswordField txtPassNueva;
    @FXML private PasswordField txtPassConfirmar;
    @FXML private Label lblMensaje;

    @Autowired private UsuarioService usuarioService;
    @Autowired private PasswordEncoder passwordEncoder;

    @FXML
    private void cambiarContrasena() {
        String actual = txtPassActual.getText();
        String nueva = txtPassNueva.getText();
        String confirmar = txtPassConfirmar.getText();

        if (actual.isEmpty() || nueva.isEmpty()) {
            mostrarMensaje("Complete todos los campos.", true);
            return;
        }
        if (!nueva.equals(confirmar)) {
            mostrarMensaje("La nueva contraseña no coincide con la confirmación.", true);
            return;
        }

        // Obtener usuario actual
        Long userId = SessionManager.getInstance().getUserId();
        if (userId == null) {
            mostrarMensaje("Error de sesión. Reinicie la aplicación.", true);
            return;
        }

        Usuario usuario = usuarioService.findById(userId);

        // Verificar contraseña actual
        if (!passwordEncoder.matches(actual, usuario.getPassword())) {
            mostrarMensaje("La contraseña actual es incorrecta.", true);
            return;
        }

        // Guardar nueva
        usuario.setPassword(passwordEncoder.encode(nueva));
        usuarioService.update(userId, usuario);

        mostrarMensaje("Contraseña actualizada correctamente.", false);
        txtPassActual.clear();
        txtPassNueva.clear();
        txtPassConfirmar.clear();
    }

    private void mostrarMensaje(String msg, boolean error) {
        lblMensaje.setText(msg);
        lblMensaje.setStyle(error ? "-fx-text-fill: red;" : "-fx-text-fill: green;");
    }
}