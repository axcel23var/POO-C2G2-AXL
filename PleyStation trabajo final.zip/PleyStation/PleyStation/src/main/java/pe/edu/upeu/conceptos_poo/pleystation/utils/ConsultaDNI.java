package pe.edu.upeu.conceptos_poo.pleystation.utils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class ConsultaDNI {

    /**
     * Busca datos de una persona por DNI en el sitio web eldni.com
     * @param dni El DNI de 8 dígitos a buscar.
     * @return Un Map con "dni", "nombres" y "direccion" si se encuentra, o un Map vacío si no.
     */
    public Map<String, String> buscarDatosPorDni(String dni) {
        Map<String, String> datos = new HashMap<>();
        if (dni == null || dni.length() != 8 || !dni.matches("\\d+")) {
            System.err.println("DNI inválido. Debe tener 8 dígitos numéricos.");
            return datos;
        }

        try {
            String url = "https://eldni.com/pe/buscar-datos-por-dni";

            // Realizar la petición POST con el DNI
            Document doc = Jsoup.connect(url)
                    .data("dni", dni)
                    .data("Buscar", "Buscar") // Simula el clic en el botón
                    .post();

            // ----- INICIO DE LA MODIFICACIÓN -----
            // La web ahora usa divs con clases "card-body" y "row"
            Element cardBody = doc.select("div.card-body").first();

            if (cardBody != null) {
                Elements rows = cardBody.select("div.row");

                // La estructura esperada ahora es:
                // Fila 1 (rows.get(0)): DNI
                // Fila 2 (rows.get(1)): Nombres
                // Fila 3 (rows.get(2)): Dirección

                if (rows.size() >= 3) {
                    // Extraer DNI (Validación)
                    String dniEncontrado = rows.get(0).select("div").get(1).text();

                    if(dniEncontrado.equals(dni)) {
                        // Extraer Nombres
                        String nombres = rows.get(1).select("div").get(1).text();
                        // Extraer Dirección
                        String direccion = rows.get(2).select("div").get(1).text();

                        datos.put("dni", dniEncontrado);
                        datos.put("nombres", nombres);
                        datos.put("direccion", direccion);
                    }
                } else {
                    System.err.println("No se encontraron las filas (div.row) esperadas para el DNI: " + dni);
                }
            } else {
                // Puede que no encuentre la tabla si el DNI es inválido o la web cambió
                System.err.println("No se encontró el 'div.card-body' de resultados en la página para el DNI: " + dni);
            }
            // ----- FIN DE LA MODIFICACIÓN -----

        } catch (Exception e) {
            System.err.println("Error al conectar o parsear la web de DNI: " + e.getMessage());
            e.printStackTrace();
        }

        return datos;
    }
}