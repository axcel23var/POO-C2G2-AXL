package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import net.sf.jasperreports.engine.JasperPrint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.components.ReportDialog;
import pe.edu.upeu.conceptos_poo.pleystation.service.ReportService;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

@Controller
public class ReportesController {

    @FXML private DatePicker dpFechaInicio;
    @FXML private DatePicker dpFechaFin;
    @FXML private Button btnGenerarReporteVentas;

    @Autowired
    private ReportService reportService;

    @FXML
    public void initialize() {
        // Por defecto ponemos el mes actual para que no salga vacío
        dpFechaInicio.setValue(LocalDate.now().withDayOfMonth(1));
        dpFechaFin.setValue(LocalDate.now());
    }

    // --- MÉTODOS DE LOS BOTONES RÁPIDOS (NUEVO) ---

    @FXML
    private void reporteSemanal() {
        // Calcula desde hace 7 días hasta hoy
        LocalDate fin = LocalDate.now();
        LocalDate inicio = fin.minusDays(7);

        // Actualizamos los calendarios visualmente
        dpFechaInicio.setValue(inicio);
        dpFechaFin.setValue(fin);

        // Generamos
        generarReporteComun(inicio, fin);
    }

    @FXML
    private void reporteMensual() {
        // Calcula desde el día 1 de este mes hasta hoy
        LocalDate fin = LocalDate.now();
        LocalDate inicio = fin.with(TemporalAdjusters.firstDayOfMonth());

        dpFechaInicio.setValue(inicio);
        dpFechaFin.setValue(fin);
        generarReporteComun(inicio, fin);
    }

    @FXML
    private void reporteAnual() {
        // Calcula desde el 1 de Enero hasta hoy
        LocalDate fin = LocalDate.now();
        LocalDate inicio = fin.with(TemporalAdjusters.firstDayOfYear());

        dpFechaInicio.setValue(inicio);
        dpFechaFin.setValue(fin);
        generarReporteComun(inicio, fin);
    }

    // --- MÉTODO DEL BOTÓN MANUAL ORIGINAL ---

    @FXML
    private void generarReporteVentas() {
        LocalDate fechaInicio = dpFechaInicio.getValue();
        LocalDate fechaFin = dpFechaFin.getValue();

        if (fechaInicio == null || fechaFin == null) {
            mostrarAlerta("Error", "Debe seleccionar una fecha de inicio y fin.", Alert.AlertType.ERROR);
            return;
        }
        if (fechaFin.isBefore(fechaInicio)) {
            mostrarAlerta("Error", "La fecha de fin no puede ser anterior a la fecha de inicio.", Alert.AlertType.ERROR);
            return;
        }

        generarReporteComun(fechaInicio, fechaFin);
    }

    // --- MÉTODO CENTRAL QUE HACE EL TRABAJO ---
    private void generarReporteComun(LocalDate inicio, LocalDate fin) {
        try {
            JasperPrint jasperPrint = reportService.generarReporteVentas(inicio, fin);

            if (jasperPrint == null) {
                mostrarAlerta("Error", "El reporte salió vacío o nulo. Revisa la base de datos.", Alert.AlertType.ERROR);
                return;
            }

            // Mostrar el reporte en la ventana flotante
            ReportDialog reportDialog = new ReportDialog(jasperPrint);
            reportDialog.show();

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Error crítico", "No se pudo generar el reporte: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}