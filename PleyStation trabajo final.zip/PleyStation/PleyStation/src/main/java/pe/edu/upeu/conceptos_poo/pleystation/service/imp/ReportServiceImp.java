package pe.edu.upeu.conceptos_poo.pleystation.service.imp;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRSaver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Producto;
import pe.edu.upeu.conceptos_poo.pleystation.service.ReportService;

import javax.sql.DataSource;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportServiceImp implements ReportService {

    @Autowired
    private DataSource dataSource;

    @Override
    public JasperPrint generarReporteVentas(LocalDate fechaInicio, LocalDate fechaFin) {
        try (Connection connection = dataSource.getConnection()) {
            // 1. Cargar reporte
            InputStream reportStream = new ClassPathResource("jasper/reporte_ventas.jrxml").getInputStream();
            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            // 2. Parámetros
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("fechaI", fechaInicio.toString());
            parameters.put("fechaF", fechaFin.toString());

            // CORRECCIÓN: Pasar la URL como String, no como InputStream
            String logoPath = new ClassPathResource("img/playstation_logo.png").getURL().toString();
            parameters.put("imagenurl", logoPath);

            return JasperFillManager.fillReport(jasperReport, parameters, connection);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error generando el reporte de ventas: " + e.getMessage(), e);
        }
    }

    @Override
    public byte[] generarBoletaPdf(Long idVenta) {
        try (Connection connection = dataSource.getConnection()) {
            // 1. Cargar Reporte Principal
            InputStream mainReportStream = new ClassPathResource("jasper/comprobante.jrxml").getInputStream();
            JasperReport mainReport = JasperCompileManager.compileReport(mainReportStream);

            // 2. Compilar Subreporte y guardarlo en temporal
            InputStream subReportStream = new ClassPathResource("jasper/detallev.jrxml").getInputStream();
            JasperReport subReport = JasperCompileManager.compileReport(subReportStream);
            File tempSubReport = File.createTempFile("detallev", ".jasper");
            JRSaver.saveObject(subReport, tempSubReport.getAbsolutePath());

            // 3. Parámetros
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("idventa", idVenta);
            parameters.put("urljasper", tempSubReport.getAbsolutePath()); // Ruta del subreporte compilado

            // CORRECCIÓN: Pasar la URL como String para que coincida con el JRXML
            String logoPath = new ClassPathResource("img/playstation_logo.png").getURL().toString();
            parameters.put("imagenurl", logoPath);

            // 4. Llenar reporte
            JasperPrint jasperPrint = JasperFillManager.fillReport(mainReport, parameters, connection);

            // 5. Exportar a PDF
            return JasperExportManager.exportReportToPdf(jasperPrint);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error generando PDF de boleta: " + e.getMessage());
        }
    }

    @Override
    public byte[] generarProformaPdf(List<Producto> productos) {
        try {
            // 1. Cargar el reporte de proforma
            InputStream reportStream = new ClassPathResource("jasper/proforma_productos.jrxml").getInputStream();
            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            // 2. Parámetros (Logo)
            Map<String, Object> parameters = new HashMap<>();
            String logoPath = new ClassPathResource("img/playstation_logo.png").getURL().toString();
            parameters.put("imagenurl", logoPath);

            // 3. Crear Datasource desde la LISTA DE JAVA (No desde SQL)
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(productos);

            // 4. Llenar
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);

            // 5. Exportar
            return JasperExportManager.exportReportToPdf(jasperPrint);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error generando PDF de proforma: " + e.getMessage());
        }
    }
}