package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.components.ColumnInfo;
import pe.edu.upeu.conceptos_poo.pleystation.components.TableViewHelper;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Categoria;
import pe.edu.upeu.conceptos_poo.pleystation.service.CategoriaIService;

import java.util.LinkedHashMap;

@Controller
public class GestionCategoriasController {

    @FXML private TextField txtNombreCategoria;
    @FXML private Button btnGuardar;
    @FXML private Label lblMensaje;
    @FXML private TableView<Categoria> tableViewCategorias;

    @Autowired
    private CategoriaIService categoriaService;

    private Long idCategoriaEditando = null;
    private ObservableList<Categoria> listaCategoriasObservable;

    @FXML
    public void initialize() {
        configurarTabla();
        listarCategorias();
        cancelarEdicion(); // Para limpiar estado inicial
    }

    private void configurarTabla() {
        TableViewHelper<Categoria> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columnas = new LinkedHashMap<>();

        // Definimos las columnas: Título Columna -> (Campo Modelo, Ancho)
        columnas.put("ID", new ColumnInfo("idCategoria", 50.0));
        columnas.put("Nombre Categoría", new ColumnInfo("nombre", 200.0));

        helper.addColumnsInOrderWithSize(tableViewCategorias, columnas, this::editarCategoria, this::eliminarCategoria);
    }

    private void listarCategorias() {
        try {
            // Usamos findAll() de la interfaz genérica
            listaCategoriasObservable = FXCollections.observableArrayList(categoriaService.findAll());
            tableViewCategorias.setItems(listaCategoriasObservable);
        } catch (Exception e) {
            lblMensaje.setText("Error al listar: " + e.getMessage());
            lblMensaje.setStyle("-fx-text-fill: red;");
        }
    }

    @FXML
    private void guardarCategoria() {
        String nombre = txtNombreCategoria.getText().trim();

        if (nombre.isEmpty()) {
            mostrarMensaje("El nombre es obligatorio.", true);
            return;
        }

        try {
            Categoria categoria;
            if (idCategoriaEditando != null) {
                // Editar
                categoria = categoriaService.findById(idCategoriaEditando);
                if (categoria != null) {
                    categoria.setNombre(nombre);
                    categoriaService.update(idCategoriaEditando, categoria);
                    mostrarMensaje("Categoría actualizada.", false);
                }
            } else {
                // Crear Nueva
                categoria = new Categoria();
                categoria.setNombre(nombre);
                categoriaService.save(categoria);
                mostrarMensaje("Categoría creada.", false);
            }

            cancelarEdicion();
            listarCategorias();

        } catch (Exception e) {
            mostrarMensaje("Error al guardar: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void editarCategoria(Categoria categoria) {
        idCategoriaEditando = categoria.getIdCategoria();
        txtNombreCategoria.setText(categoria.getNombre());
        btnGuardar.setText("Actualizar");
        mostrarMensaje("Editando ID: " + idCategoriaEditando, false);
        lblMensaje.setStyle("-fx-text-fill: blue;");
    }

    private void eliminarCategoria(Categoria categoria) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Borrar categoría '" + categoria.getNombre() + "'?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try {
                    categoriaService.delete(categoria.getIdCategoria());
                    mostrarMensaje("Categoría eliminada.", false);
                    listarCategorias();
                } catch (Exception e) {
                    mostrarMensaje("Error: No se puede eliminar (puede estar en uso).", true);
                }
            }
        });
    }

    @FXML
    private void cancelarEdicion() {
        idCategoriaEditando = null;
        txtNombreCategoria.clear();
        btnGuardar.setText("Guardar");
        lblMensaje.setText("");
        // Limpiar selección de la tabla si deseas
        tableViewCategorias.getSelectionModel().clearSelection();
    }

    private void mostrarMensaje(String msg, boolean error) {
        lblMensaje.setText(msg);
        lblMensaje.setStyle(error ? "-fx-text-fill: red;" : "-fx-text-fill: green;");
    }
}