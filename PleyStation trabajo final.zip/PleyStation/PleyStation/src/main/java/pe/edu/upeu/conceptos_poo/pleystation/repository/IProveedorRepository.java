package pe.edu.upeu.conceptos_poo.pleystation.repository;

import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Proveedor;

@Repository
public interface IProveedorRepository extends ICrudGenericoRepository<Proveedor, Long> {
}