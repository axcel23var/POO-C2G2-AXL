package pe.edu.upeu.conceptos_poo.pleystation.modelos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.conceptos_poo.pleystation.enums.TipoDocumento;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Table(name = "PleyStation_Cliente")
public class Cliente {
    @Id
    @Column(name = "dni_ruc", nullable = false)
    private String dniruc;

    @Column(name = "nombres", nullable = false)
    private String nombres;

    @Column(name = "tipo_documento", nullable = false)
    @Enumerated(EnumType.STRING)
    private TipoDocumento tipoDocumento;

    @Column(name = "direccion")
    private String direccion;

    @Column(name = "email") // Nuevo campo
    private String email;
}