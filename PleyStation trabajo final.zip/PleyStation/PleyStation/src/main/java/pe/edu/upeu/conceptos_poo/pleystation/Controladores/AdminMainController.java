package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.components.StageManager;
import pe.edu.upeu.conceptos_poo.pleystation.service.BackupService;

import java.io.File;
import java.io.IOException;
import java.util.prefs.Preferences;

@Controller
public class AdminMainController {
    @Autowired private ConfigurableApplicationContext applicationContext;
    @Autowired private BackupService backupService;

    @FXML private BorderPane bpAdminMain;
    @FXML private MenuBar menuBarAdmin;
    @FXML private TabPane tabPaneAdmin;
    @FXML private Menu menuEstilo;
    @FXML private Menu menuIdioma;

    private ComboBox<String> comboBoxEstilos;
    private ComboBox<String> comboBoxIdiomas;
    Preferences userPrefs = Preferences.userRoot().node("pe/edu/upeu/pleystation/prefs");

    @FXML
    public void initialize() {
        configurarMenuEstilo();
        configurarMenuIdioma();
        // Abrir Caja (o intentar) al iniciar el admin también es útil,
        // pero lo dejaremos en Dashboard como vista principal.
        abrirDashboard(null);
    }

    // ==========================================
    //        MENÚ VENTAS (Funciones Vendedor)
    // ==========================================
    @FXML private void abrirCaja(ActionEvent event) { abrirTabConFXML("/fxml/apertura_cierre_caja.fxml", "Control de Caja"); }
    @FXML private void abrirRegistroVenta(ActionEvent event) { abrirTabConFXML("/fxml/cliente_main.fxml", "Punto de Venta (POS)"); }
    @FXML private void abrirHistorialVentas(ActionEvent event) { abrirTabConFXML("/fxml/historial_ventas.fxml", "Historial de Ventas"); }
    @FXML private void abrirBuscadorPrecios(ActionEvent event) { abrirTabConFXML("/fxml/buscador_precios.fxml", "Consulta de Precios"); }

    // ==========================================
    //        MENÚ GESTIONAR
    // ==========================================
    @FXML private void abrirGestionProductos(ActionEvent event) { abrirTabConFXML("/fxml/gestionar_productos.fxml", "Gestionar Productos"); }
    @FXML private void abrirGestionClientes(ActionEvent event) { abrirTabConFXML("/fxml/gestionar_clientes.fxml", "Gestionar Clientes"); }
    @FXML private void abrirGestionUsuarios(ActionEvent event) { abrirTabConFXML("/fxml/admin_gestionar_usuarios.fxml", "Gestionar Usuarios"); }
    @FXML private void abrirGestionCategorias(ActionEvent event) { abrirTabConFXML("/fxml/gestionar_categorias.fxml", "Categorías"); }
    @FXML private void abrirGestionUnidades(ActionEvent event) { abrirTabConFXML("/fxml/gestionar_unidades_medida.fxml", "Unidades de Medida"); }

    // ==========================================
    //        MENÚ LOGÍSTICA
    // ==========================================
    @FXML private void abrirGestionProveedores(ActionEvent event) { abrirTabConFXML("/fxml/gestionar_proveedores.fxml", "Proveedores"); }
    @FXML private void abrirRegistroCompra(ActionEvent event) { abrirTabConFXML("/fxml/registro_compra.fxml", "Registrar Compra"); }

    // ==========================================
    //        MENÚ REPORTES
    // ==========================================
    @FXML private void abrirReporteVentas(ActionEvent event) { abrirTabConFXML("/fxml/reportes_main.fxml", "Reporte Ventas"); }

    // ==========================================
    //        MENÚ ARCHIVO / SISTEMA
    // ==========================================
    @FXML private void abrirDashboard(ActionEvent event) { abrirTabConFXML("/fxml/dashboard.fxml", "Dashboard"); }
    @FXML private void abrirCambioClave(ActionEvent event) { abrirTabConFXML("/fxml/cambio_clave.fxml", "Cambiar Contraseña"); }

    @FXML
    private void realizarBackup(ActionEvent event) {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        directoryChooser.setTitle("Seleccionar carpeta para Backup");
        File selectedDirectory = directoryChooser.showDialog(bpAdminMain.getScene().getWindow());

        if (selectedDirectory != null) {
            try {
                backupService.realizarBackup(selectedDirectory);
                new Alert(Alert.AlertType.INFORMATION, "Copia de seguridad realizada exitosamente.").show();
            } catch (Exception e) {
                e.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Error al crear backup: " + e.getMessage()).show();
            }
        }
    }

    @FXML
    private void cerrarSesion(ActionEvent event) {
        try {
            Stage stage = StageManager.getPrimaryStage();
            if (stage == null) stage = (Stage) bpAdminMain.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            fxmlLoader.setControllerFactory(applicationContext::getBean);
            Parent loginRoot = fxmlLoader.load();
            Scene scene = new Scene(loginRoot);
            stage.setScene(scene);
            stage.setTitle("PleyStation - Iniciar Sesión");
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML private void salirAplicacion(ActionEvent event) { Platform.exit(); System.exit(0); }

    // ==========================================
    //        UTILITARIOS
    // ==========================================
    private void abrirTabConFXML(String fxmlPath, String tituloTab) {
        // Verificar si la pestaña ya está abierta
        for (Tab tab : tabPaneAdmin.getTabs()) {
            if (tab.getText().equals(tituloTab)) {
                tabPaneAdmin.getSelectionModel().select(tab);
                return;
            }
        }
        // Cargar nueva pestaña
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            loader.setControllerFactory(applicationContext::getBean);
            Parent root = loader.load();
            Tab nuevaPestana = new Tab(tituloTab);
            nuevaPestana.setContent(root);
            tabPaneAdmin.getTabs().add(nuevaPestana);
            tabPaneAdmin.getSelectionModel().select(nuevaPestana);
        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "No se pudo cargar la vista: " + tituloTab + "\n" + e.getMessage());
            alert.showAndWait();
        }
    }

    private void configurarMenuEstilo() {
        comboBoxEstilos = new ComboBox<>(FXCollections.observableArrayList("Estilo por Defecto", "Estilo Oscuro", "Estilo Azul", "Estilo Verde", "Estilo Rosado"));
        comboBoxEstilos.setValue(userPrefs.get("appEstilo", "Estilo por Defecto"));
        comboBoxEstilos.setOnAction(e -> cambiarEstilo());
        CustomMenuItem item = new CustomMenuItem(comboBoxEstilos);
        item.setHideOnClick(false);
        menuEstilo.getItems().add(item);
    }

    private void cambiarEstilo() {
        String estilo = comboBoxEstilos.getValue();
        if (estilo == null || bpAdminMain.getScene() == null) return;
        Scene scene = bpAdminMain.getScene();
        scene.getStylesheets().clear();
        String css = switch (estilo) {
            case "Estilo Oscuro" -> "/css/estilo-oscuro.css";
            case "Estilo Azul" -> "/css/estilo-azul.css";
            case "Estilo Verde" -> "/css/estilo-verde.css";
            case "Estilo Rosado" -> "/css/estilo-rosado.css";
            default -> "/css/styles.css";
        };
        if (getClass().getResource(css) != null) {
            scene.getStylesheets().add(getClass().getResource(css).toExternalForm());
            userPrefs.put("appEstilo", estilo);
        }
    }

    private void configurarMenuIdioma() {
        comboBoxIdiomas = new ComboBox<>(FXCollections.observableArrayList("Español", "Inglés"));
        String langCode = userPrefs.get("appIdioma", "es");
        comboBoxIdiomas.setValue(langCode.equals("es") ? "Español" : "Inglés");
        comboBoxIdiomas.setOnAction(e -> cambiarIdioma());
        CustomMenuItem item = new CustomMenuItem(comboBoxIdiomas);
        item.setHideOnClick(false);
        menuIdioma.getItems().add(item);
    }

    private void cambiarIdioma() {
        String idioma = comboBoxIdiomas.getValue();
        userPrefs.put("appIdioma", idioma.equals("Español") ? "es" : "en");
        new Alert(Alert.AlertType.INFORMATION, "Reinicie la aplicación para aplicar el idioma.").showAndWait();
    }
}