package pe.edu.upeu.conceptos_poo.pleystation.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void enviarBoletaAsync(String destinatario, String asunto, String cuerpo, byte[] pdfBytes, String nombreArchivo) {
        CompletableFuture.runAsync(() -> {
            try {
                enviarCorreoConAdjunto(destinatario, asunto, cuerpo, pdfBytes, nombreArchivo);
                System.out.println("Correo enviado exitosamente a: " + destinatario);
            } catch (Exception e) {
                System.err.println("Error enviando correo: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    private void enviarCorreoConAdjunto(String destinatario, String asunto, String cuerpo, byte[] pdfBytes, String nombreArchivo) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setTo(destinatario);
        helper.setSubject(asunto);
        helper.setText(cuerpo);

        // Adjuntar PDF
        if (pdfBytes != null) {
            helper.addAttachment(nombreArchivo, new ByteArrayResource(pdfBytes));
        }

        mailSender.send(message);
    }
}