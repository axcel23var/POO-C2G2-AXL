package pe.edu.upeu.conceptos_poo.pleystation.service.imp;

import jakarta.transaction.Transactional;
import javafx.scene.control.ComboBox;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.annotation.RequiredTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.pleystation.dto.ComboBoxOption;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Categoria;
import pe.edu.upeu.conceptos_poo.pleystation.repository.ICategoriaRepository;
import pe.edu.upeu.conceptos_poo.pleystation.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.pleystation.service.CRUD_GenericoSefvice_Interface;
import pe.edu.upeu.conceptos_poo.pleystation.service.CategoriaIService;

import java.util.ArrayList;
import java.util.List;
@Transactional
@RequiredArgsConstructor
@Service
public class CategoriaImp extends CRUD_GenericoServiceImp<Categoria, Long> implements CategoriaIService {

    private final ICategoriaRepository categoriaRepository;

    @Override
    protected ICrudGenericoRepository<Categoria, Long> getRepository() {
        return categoriaRepository;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar=new ArrayList<>();
        ComboBoxOption cb;
        for(Categoria cate : categoriaRepository.findAll()) {
            cb=new ComboBoxOption();
            cb.setKey(String.valueOf(cate.getIdCategoria()));
            cb.setValue(cate.getNombre());
            listar.add(cb);
        }
        return listar;
    }
}
