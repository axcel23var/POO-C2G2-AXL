package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.components.ColumnInfo;
import pe.edu.upeu.conceptos_poo.pleystation.components.TableViewHelper;
import pe.edu.upeu.conceptos_poo.pleystation.dto.ComboBoxOption;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Perfil;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Usuario;
import pe.edu.upeu.conceptos_poo.pleystation.service.PerfilService;
import pe.edu.upeu.conceptos_poo.pleystation.service.UsuarioService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class Adm_UsuariosController {

    @FXML private TextField txtFiltroUsuarios;
    @FXML private TableView<Usuario> tableViewUsuarios;
    @FXML private TextField txtUsername;
    @FXML private PasswordField txtPassword;
    @FXML private ComboBox<ComboBoxOption> cbxPerfil;
    @FXML private Button btnGuardarUsuario;
    @FXML private Label lblMensajeUsuario;

    @Autowired
    private UsuarioService usuarioService;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired private PerfilService perfilService;

    private ObservableList<Usuario> listaUsuariosObservable;
    private Long idUsuarioEditando = null;

    @FXML
    public void initialize() {
        cargarPerfiles();
        configurarTablaUsuarios();
        listarUsuarios();
        txtFiltroUsuarios.textProperty().addListener((observable, oldValue, newValue) -> filtrarUsuarios(newValue));
        cancelarEdicionUsuario();
    }

    private void cargarPerfiles() {
        try {
            List<Perfil> perfiles = perfilService.findAll();
            List<ComboBoxOption> opcionesPerfil = perfiles.stream()
                    .map(p -> new ComboBoxOption(String.valueOf(p.getIdPerfil()), p.getCorreo()))
                    .collect(Collectors.toList());
            cbxPerfil.setItems(FXCollections.observableArrayList(opcionesPerfil));
        } catch (Exception e) {
            mostrarMensaje("Error al cargar perfiles: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void configurarTablaUsuarios() {
        TableViewHelper<Usuario> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columnas = new LinkedHashMap<>();

        // --- SECCIÓN CORREGIDA ---
        columnas.put("ID", new ColumnInfo("id", 60.0)); // <--- CORREGIDO (antes 'idUsuario')
        columnas.put("Nombre Usuario (Correo)", new ColumnInfo("correo", 200.0)); // <--- CORREGIDO (antes 'nombre_Usuario')
        columnas.put("Rol", new ColumnInfo("rol", 100.0)); // <-- OK
        columnas.put("Perfil (ID)", new ColumnInfo("perfil.idPerfil", 100.0)); // <--- CORREGIDO (antes 'idPerfil.id_perfil')
        // --- FIN DE CORRECCIÓN ---

        helper.addColumnsInOrderWithSize(tableViewUsuarios, columnas, this::editarUsuario, this::eliminarUsuario);
        tableViewUsuarios.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
    }

    private void listarUsuarios() {
        try {
            listaUsuariosObservable = FXCollections.observableArrayList(usuarioService.findAll());
            tableViewUsuarios.setItems(listaUsuariosObservable);
        } catch (Exception e) {
            mostrarMensaje("Error al listar usuarios: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void filtrarUsuarios(String filtro) {
        if (filtro == null || filtro.isEmpty()) {
            tableViewUsuarios.setItems(listaUsuariosObservable);
        } else {
            String lowerCaseFilter = filtro.toLowerCase();
            List<Usuario> filtradosList = listaUsuariosObservable.stream()
                    .filter(u -> u.getCorreo().toLowerCase().contains(lowerCaseFilter) ||
                            (u.getRol() != null && u.getRol().toLowerCase().contains(lowerCaseFilter)))
                    .collect(Collectors.toList());
            ObservableList<Usuario> filtradosObservable = FXCollections.observableArrayList(filtradosList);
            tableViewUsuarios.setItems(filtradosObservable);
        }
    }

    @FXML
    private void guardarUsuario() {
        String username = txtUsername.getText().trim();
        String password = txtPassword.getText();
        ComboBoxOption perfilSeleccionado = cbxPerfil.getSelectionModel().getSelectedItem();

        if (username.isEmpty() || perfilSeleccionado == null) {
            mostrarMensaje("Nombre de usuario y rol son obligatorios.", true);
            return;
        }
        if (idUsuarioEditando == null && password.isEmpty()) {
            mostrarMensaje("La contraseña es obligatoria para nuevos usuarios.", true);
            return;
        }

        try {
            Usuario usuario = (idUsuarioEditando != null) ? usuarioService.findById(idUsuarioEditando) : new Usuario();
            if (usuario == null && idUsuarioEditando != null) {
                mostrarMensaje("Error: No se encontró el usuario a editar.", true);
                return;
            }
            if (usuario == null) usuario = new Usuario();

            if (idUsuarioEditando == null || !usuario.getCorreo().equals(username)) {
                if (usuarioService.existeUsuario(username)) {
                    mostrarMensaje("El nombre de usuario (correo) ya está en uso.", true);
                    return;
                }
            }

            usuario.setCorreo(username);
            if (!password.isEmpty()) {
                usuario.setPassword(passwordEncoder.encode(password)); // Esta línea estaba correcta
            } else if (idUsuarioEditando == null) {
                mostrarMensaje("La contraseña es obligatoria para nuevos usuarios.", true);
                return;
            }
            Perfil perfil = perfilService.findById(Long.parseLong(perfilSeleccionado.getKey()));
            if (perfil == null) {
                mostrarMensaje("Error: Perfil seleccionado no válido.", true);
                return;
            }
            usuario.setPerfil(perfil);

            // Asignar rol basado en el perfil (lógica añadida para consistencia)
            // Asumimos que el "correo" del perfil es el nombre del Rol.
            // Si esta lógica es incorrecta, ajústala.
            if (perfil.getCorreo().equalsIgnoreCase("admin@pleystation.com")) {
                usuario.setRol("Administrador");
            } else if (perfil.getCorreo().equalsIgnoreCase("cliente@gmail.com")) {
                usuario.setRol("Cliente");
            } else {
                usuario.setRol("Vendedor"); // Asumir Vendedor por defecto si no es admin o cliente
            }


            if (idUsuarioEditando == null) {
                usuarioService.save(usuario);
                mostrarMensaje("Usuario creado exitosamente.", false);
            } else {
                usuario.setId(idUsuarioEditando);
                usuarioService.update(idUsuarioEditando, usuario);
                mostrarMensaje("Usuario actualizado exitosamente.", false);
            }

            cancelarEdicionUsuario();
            listarUsuarios();

        } catch (Exception e) {
            mostrarMensaje("Error al guardar usuario: " + e.getMessage(), true);
            e.printStackTrace();
        }
    }

    private void editarUsuario(Usuario usuario) {
        idUsuarioEditando = usuario.getId();
        txtUsername.setText(usuario.getCorreo());
        txtPassword.setPromptText("Dejar vacío para no cambiar");
        txtPassword.clear();

        String perfilIdStr = String.valueOf(usuario.getPerfil().getIdPerfil());
        for (ComboBoxOption option : cbxPerfil.getItems()) {
            if (option.getKey().equals(perfilIdStr)) {
                cbxPerfil.setValue(option);
                break;
            }
        }

        lblMensajeUsuario.setText("Editando usuario ID: " + idUsuarioEditando);
        lblMensajeUsuario.setStyle("-fx-text-fill: blue;");
        btnGuardarUsuario.setText("Actualizar");
    }

    private void eliminarUsuario(Usuario usuario) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Está seguro de eliminar al usuario '" + usuario.getCorreo() + "'?", ButtonType.YES, ButtonType.NO); // <-- Mensaje mejorado
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try {
                    usuarioService.delete(usuario.getId());
                    mostrarMensaje("Usuario eliminado exitosamente.", false);
                    listarUsuarios();
                } catch (Exception e) {
                    mostrarMensaje("Error al eliminar usuario: " + e.getMessage(), true);
                    e.printStackTrace();
                }
            }
        });
    }

    @FXML
    private void cancelarEdicionUsuario() {
        idUsuarioEditando = null;
        txtUsername.clear();
        txtPassword.clear();
        txtPassword.setPromptText("Contraseña");
        cbxPerfil.getSelectionModel().clearSelection();
        lblMensajeUsuario.setText("");
        btnGuardarUsuario.setText("Guardar");
        limpiarEstilosError();
    }

    private void mostrarMensaje(String mensaje, boolean esError) {
        lblMensajeUsuario.setText(mensaje);
        if (esError) {
            lblMensajeUsuario.setStyle("-fx-text-fill: red;");
        } else {
            lblMensajeUsuario.setStyle("-fx-text-fill: green;");
        }
    }

    private void limpiarEstilosError() {
        txtUsername.getStyleClass().remove("text-field-error");
        txtPassword.getStyleClass().remove("text-field-error");
        cbxPerfil.getStyleClass().remove("text-field-error");
    }
}