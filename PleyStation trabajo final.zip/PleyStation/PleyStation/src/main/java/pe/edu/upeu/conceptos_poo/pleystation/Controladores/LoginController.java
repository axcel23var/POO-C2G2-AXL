package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.components.StageManager;
import pe.edu.upeu.conceptos_poo.pleystation.dto.SessionManager;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Usuario;
import pe.edu.upeu.conceptos_poo.pleystation.service.UsuarioService;

import java.io.IOException;

@Controller
public class LoginController {
    // --- Componentes FXML ---
    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Button backButton;

    @FXML
    private Label errorMessageLabel;

    // --- Servicios de Spring ---
    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private ConfigurableApplicationContext applicationContext;

    @FXML
    public void initialize() {
        // Asignamos las acciones a los botones
        loginButton.setOnAction(e -> Entrar());
        backButton.setOnAction(e -> Volver());
    }

    @FXML
    private void Entrar() {
        String username = emailField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            errorMessageLabel.setText("El usuario y la contraseña no pueden estar vacíos.");
            return;
        }

        try {
            Usuario usuario = usuarioService.loginUsuario(username, password);

            if (usuario != null) {
                errorMessageLabel.setText("¡Login exitoso! Bienvenido.");

                // Guardar datos del usuario logueado (si es necesario)
                // SessionManager.getInstance().setUserId(usuario.getIdUsuario());
                // SessionManager.getInstance().setUserName(usuario.getNombre_Usuario());
                // SessionManager.getInstance().setUserPerfil(usuario.getRol());

                if ("Administrador".equalsIgnoreCase(usuario.getRol())) {
                    // Cargar la interfaz de Administrador
                    cargarEscenaAdmin("/fxml/Admi_Main.fxml", "Panel de Administrador");

                    // --- INICIO DE LA MODIFICACIÓN ---
                } else if ("Vendedor".equalsIgnoreCase(usuario.getRol())) {
                    // Cargar la interfaz de Vendedor
                    cargarEscenaGenerica("/fxml/vendedor_main.fxml", "Panel de Vendedor - PleyStation");
                    // --- FIN DE LA MODIFICACIÓN ---

                } else if ("Cliente".equalsIgnoreCase(usuario.getRol())) {
                    // Cargar la interfaz de Cliente
                    cargarEscenaGenerica("/fxml/cliente_main.fxml", "Tienda PleyStation");
                } else {
                    // Otros roles
                    errorMessageLabel.setText("Login exitoso (" + usuario.getRol() + "). Interfaz en construcción.");
                }

            } else {
                // Falla de Login (usuario o contraseña incorrectos)
                errorMessageLabel.setText("Usuario o contraseña incorrectos. Inténtelo de nuevo.");
            }
        } catch (Exception e) {
            errorMessageLabel.setText("Error al conectar con la base de datos.");
            e.printStackTrace();
        }
    }

    @FXML
    private void Volver() {
        loadScene("/fxml/PrimeraCapa.fxml");
    }

    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            fxmlLoader.setControllerFactory(applicationContext::getBean);
            Parent parent = fxmlLoader.load();

            Stage stage = StageManager.getPrimaryStage();

            if (stage != null) {
                Scene scene = new Scene(parent);
                stage.setScene(scene); // Cambiamos la escena
            } else {
                System.err.println("Error: StageManager no tiene un Stage principal asignado.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al cargar el FXML: " + fxmlPath);
        }
    }

    private void cargarEscenaAdmin(String fxmlPath, String title) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            fxmlLoader.setControllerFactory(applicationContext::getBean);
            Parent root = fxmlLoader.load();
            Stage stage = StageManager.getPrimaryStage();

            // Añadir ícono (si no lo has hecho ya en PleyStationAplication.java)
            try {
                stage.getIcons().add(new Image(getClass().getResource("/img/playstation_logo.png").toExternalForm()));
            } catch (Exception e) {
                System.err.println("No se pudo cargar el ícono de la aplicación.");
            }

            if (stage == null) {
                stage = (Stage) loginButton.getScene().getWindow();
            }

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle(title);
            stage.centerOnScreen(); // Centrar la ventana del admin

        } catch (IOException e) {
            errorMessageLabel.setText("Error fatal: No se pudo cargar la interfaz principal.");
            e.printStackTrace();
        }
    }

    private void cargarEscenaGenerica(String fxmlPath, String title) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            fxmlLoader.setControllerFactory(applicationContext::getBean); // Importante para Spring
            Parent root = fxmlLoader.load();

            Stage stage = StageManager.getPrimaryStage();
            if (stage == null) {
                stage = (Stage) loginButton.getScene().getWindow();
            }

            // Añadir ícono
            try {
                stage.getIcons().add(new Image(getClass().getResource("/img/playstation_logo.png").toExternalForm()));
            } catch (Exception e) {
                System.err.println("No se pudo cargar el ícono de la aplicación.");
            }

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle(title);
            stage.centerOnScreen();

        } catch (IOException e) {
            errorMessageLabel.setText("Error fatal: No se pudo cargar la interfaz: " + fxmlPath);
            e.printStackTrace();
        }
    }
}