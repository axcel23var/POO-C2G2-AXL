package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.service.CajaService;

@Controller
public class CajaController {
    @FXML private TextField txtMontoInicial;
    @FXML private Button btnAbrir;
    @FXML private TextField txtMontoReal;
    @FXML private Button btnCerrar;
    @FXML private Label lblEstado;

    @Autowired private CajaService cajaService;

    @FXML
    public void initialize() {
        actualizarEstado();
    }

    private void actualizarEstado() {
        boolean abierta = cajaService.hayCajaAbierta();
        btnAbrir.setDisable(abierta);
        txtMontoInicial.setDisable(abierta);

        btnCerrar.setDisable(!abierta);
        txtMontoReal.setDisable(!abierta);

        lblEstado.setText(abierta ? "Estado: CAJA ABIERTA" : "Estado: CAJA CERRADA");
        lblEstado.setStyle(abierta ? "-fx-text-fill: green;" : "-fx-text-fill: red;");
    }

    @FXML
    private void abrirCaja() {
        try {
            double monto = Double.parseDouble(txtMontoInicial.getText());
            cajaService.abrirCaja(monto);
            actualizarEstado();
            new Alert(Alert.AlertType.INFORMATION, "Caja Abierta").show();
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Error: " + e.getMessage()).show();
        }
    }

    @FXML
    private void cerrarCaja() {
        try {
            double monto = Double.parseDouble(txtMontoReal.getText());
            cajaService.cerrarCaja(monto);
            actualizarEstado();
            new Alert(Alert.AlertType.INFORMATION, "Caja Cerrada").show();
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Error: " + e.getMessage()).show();
        }
    }
}