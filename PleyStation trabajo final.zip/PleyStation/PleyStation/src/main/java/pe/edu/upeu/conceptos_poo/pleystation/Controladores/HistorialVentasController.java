package pe.edu.upeu.conceptos_poo.pleystation.Controladores;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.DetalleVenta;
import pe.edu.upeu.conceptos_poo.pleystation.modelos.Venta;
import pe.edu.upeu.conceptos_poo.pleystation.service.VentaService;
import pe.edu.upeu.conceptos_poo.pleystation.utils.PrinterUtil;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
public class HistorialVentasController {

    @FXML private DatePicker dpFecha;
    @FXML private TableView<Venta> tablaVentas;
    @FXML private TableColumn<Venta, Long> colId;
    @FXML private TableColumn<Venta, String> colFecha;
    @FXML private TableColumn<Venta, String> colCliente;
    @FXML private TableColumn<Venta, Double> colTotal;
    @FXML private TableColumn<Venta, Void> colAccion;

    @Autowired private VentaService ventaService;

    @FXML
    public void initialize() {
        dpFecha.setValue(LocalDate.now());
        configurarTabla();
        buscarVentas();
    }

    private void configurarTabla() {
        colId.setCellValueFactory(new PropertyValueFactory<>("idVenta"));
        colFecha.setCellValueFactory(data -> new SimpleStringProperty(
                data.getValue().getFechaGeneracion().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
        ));
        colCliente.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCliente().getNombres()));
        colTotal.setCellValueFactory(new PropertyValueFactory<>("total"));

        colAccion.setCellFactory(param -> new TableCell<>() {
            private final Button btnImprimir = new Button("Reimprimir");
            {
                btnImprimir.setStyle("-fx-background-color: #17a2b8; -fx-text-fill: white;");
                btnImprimir.setOnAction(e -> {
                    Venta v = getTableView().getItems().get(getIndex());
                    reimprimirBoleta(v);
                });
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnImprimir);
            }
        });
    }

    @FXML
    private void buscarVentas() {
        if (dpFecha.getValue() != null) {
            List<Venta> ventas = ventaService.findVentasBetweenFechas(
                    dpFecha.getValue().atStartOfDay(),
                    dpFecha.getValue().atTime(23, 59, 59)
            );
            tablaVentas.setItems(FXCollections.observableArrayList(ventas));
        }
    }

    private void reimprimirBoleta(Venta venta) {
        // Lógica reutilizada de ClienteMainController (Simplificada para texto plano)
        StringBuilder sb = new StringBuilder();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        sb.append("===== REIMPRESIÓN =====\n");
        sb.append("PLEYSTATION S.A.C.\n");
        sb.append(String.format("%s: %s-%06d\n", venta.getTipoDocumento(), venta.getSerie(), venta.getIdVenta()));
        sb.append("Fecha: ").append(venta.getFechaGeneracion().format(dtf)).append("\n");
        sb.append("Cliente: ").append(venta.getCliente().getNombres()).append("\n");
        sb.append("--------------------------------\n");
        for (DetalleVenta dv : venta.getDetalleVentas()) {
            sb.append(String.format("%-15.15s %3d %6.2f\n", dv.getProducto().getNombre(), dv.getCantidad(), dv.getSubtotalProducto()));
        }
        sb.append("--------------------------------\n");
        sb.append(String.format("TOTAL: S/ %.2f\n", venta.getTotal()));

        try {
            // Imprime en la impresora por defecto (o la primera encontrada)
            List<String> impresoras = PrinterUtil.getImpresoras();
            if (!impresoras.isEmpty()) {
                PrinterUtil.imprimirTexto(sb.toString(), impresoras.get(0));
                new Alert(Alert.AlertType.INFORMATION, "Enviado a impresora: " + impresoras.get(0)).show();
            } else {
                new Alert(Alert.AlertType.WARNING, "No hay impresoras. Texto:\n" + sb.toString()).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}