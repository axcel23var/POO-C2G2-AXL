package pe.edu.upeu.conceptos_poo.pleystation.service;

import pe.edu.upeu.conceptos_poo.pleystation.modelos.Proveedor;

public interface ProveedorService extends CRUD_GenericoSefvice_Interface<Proveedor, Long> {
}